<?php

namespace NinjaTables\Database;

class DBSeeder
{
    public static function run()
    {
        
    }
}
