/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './resources/admin/**/*.{vue,js}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};

