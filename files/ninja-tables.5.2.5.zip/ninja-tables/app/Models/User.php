<?php

namespace NinjaTables\App\Models;

class User extends Model
{   
    protected $table = 'users';
}
