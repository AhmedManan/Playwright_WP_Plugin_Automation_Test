<div class="table_data_press" id="data-tables-app"></div> <?php // phpcs:ignore Internal.NoCodeFound ?>

<style id="table_designer_css">
</style>

<style id="ninja_table_designer_common_css">
</style>
