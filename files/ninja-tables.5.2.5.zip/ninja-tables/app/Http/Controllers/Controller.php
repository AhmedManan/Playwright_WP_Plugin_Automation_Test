<?php

namespace NinjaTables\App\Http\Controllers;

use NinjaTables\Framework\Http\Controller as BaseController;

abstract class Controller extends BaseController
{
    // 
}
