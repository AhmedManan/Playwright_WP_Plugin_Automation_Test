<?php

namespace NinjaTables\App;

use NinjaTables\Framework\Foundation\App as AppFacade;

class App extends AppFacade
{
    // ...
}
