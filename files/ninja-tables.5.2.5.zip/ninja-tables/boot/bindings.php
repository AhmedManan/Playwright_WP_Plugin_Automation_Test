<?php
defined('ABSPATH') or die;
/**
 * Add only the plugin specific bindings here.
 *
 * $app
 * @var NinjaTables\App\Foundation\Application
 */
